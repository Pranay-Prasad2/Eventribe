import './App.css';
import Datastate from './Context/Datastate';
import Apk from './Apk';
function App() {
  return (
    <>
    <Datastate>
      <Apk/>
    </Datastate>
    </>
  );
}

export default App;
