import React from 'react'

const CACreate = () => {
  return (
    <div>CACreate</div>
  )
}

export default CACreate