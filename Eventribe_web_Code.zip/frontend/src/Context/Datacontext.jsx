import { createContext } from "react"

const Datacontext = createContext();

export default Datacontext;